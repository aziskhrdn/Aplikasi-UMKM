import java.util.Scanner;

    public class brand {
            protected String namabrand;
            public brand(String namabrand){
            this.namabrand = namabrand;
    }
        void display(){
            System.out.println("Salam Hangat kami " +namabrand);
        }

}
